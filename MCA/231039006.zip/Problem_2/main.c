#include <lpc214x.h>
#include "header.h"

int main(void)
{
	init_pll();
	interrupt();
	serial_uart();
	lcd_init();
	return 0;
}