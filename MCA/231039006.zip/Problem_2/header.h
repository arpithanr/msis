void init_pll();
void serial_uart();
void tx(unsigned char);
char rx();
void timer0();
void interrupt();
void INT0_ISR();
void lcd_init();
void cmd(unsigned char a);
void dat(unsigned char b);
void show(unsigned char *s);
void lcd_delay();
void delayms(int count);

