#include <lpc214x.h>
#define LED_PIN1 0x01<<5;
#define LED_PIN2 0x01<<6;

void pll_init();
void delay_ms(unsigned int count);

int main()
{
	IO0DIR = 0x01<<14;// making 14 th pin as switch
	IO0DIR &= ~(0x06); 	// making LED port 0.5 and 0.6 as output pin
	IO0SET |= 0x06; // set port 0.5 and 0.6 as high
	pll_init();
	while(1)
	{
	if((IO0PIN & 0x01<<14))
		{
			IO0SET = LED_PIN1; // port0.5 as high
			delay_ms(1);
			IO0SET = LED_PIN2; // port0.6 as high
			IO0SET = LED_PIN2; //port 0.6 as high
			delay_ms(2);
		}else
		{	
			IO0CLR = LED_PIN1; // clear port 0.5
			delay_ms(1);
			IO0CLR = LED_PIN2; // clear port 0.5
			IO0CLR = LED_PIN2; // clear port 0.5
			delay_ms(2);
		}
	}	
	return 0;
}

void pll_init(void)
{
	PLL0CON = 0x01; // Select Pin Select
	PLL0CFG = 0x24;	// Select pin configuration
	PLL0FEED = 0xAA;// Unlock pll0
	PLL0FEED = 0X55;// Unlock pll0
	while((PLL0STAT & (0x01<<10))==0);
	PLL0CON = 0x03; //select pin configuration
	PLL0FEED = 0xAA;//lock pll0
	PLL0FEED = 0x55;//lock pll0
}

void delay_ms(unsigned int count)
{
	int i,j;
	for(i=0; i<count; i++)
	{
		for(j=0; j<6000; j++);
	}
}